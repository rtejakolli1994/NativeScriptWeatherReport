webpackHotUpdate("bundle",{

/***/ "./app/weather-report.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WeatherReportComponent", function() { return WeatherReportComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("@angular/core");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_angular_core__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _weather_report_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./app/weather-report.service.ts");


var WeatherReportComponent = /** @class */ (function () {
    function WeatherReportComponent(weatherReportService, vcr) {
        this.weatherReportService = weatherReportService;
        this.vcr = vcr;
        this.cityName = '';
        this.currentCityName = '';
        this.gridstatus = false;
        this.errInfo = '';
    }
    WeatherReportComponent.prototype.ngOnInit = function () { };
    WeatherReportComponent.prototype.onChange = function () {
        var _this = this;
        this.currentCityName = this.cityName;
        return this.weatherReportService.searchCity(this.currentCityName).subscribe(function (data) {
            _this.cityReport = data;
            if (_this.cityReport) {
                _this.gridstatus = true;
            }
            else {
                _this.gridstatus = false;
            }
        }, function (err) {
            _this.gridstatus = false;
            _this.errInfo = err.error.message;
        });
    };
    WeatherReportComponent.ctorParameters = function () { return [
        { type: _weather_report_service__WEBPACK_IMPORTED_MODULE_1__["WeatherReportService"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"] }
    ]; };
    WeatherReportComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'ns-weather-report',
            template: __webpack_require__("./app/weather-report.component.html"),
            styles: [__webpack_require__("./app/weather-report.component.css")]
        }),
        __metadata("design:paramtypes", [_weather_report_service__WEBPACK_IMPORTED_MODULE_1__["WeatherReportService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewContainerRef"]])
    ], WeatherReportComponent);
    return WeatherReportComponent;
}());



/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9hcHAvd2VhdGhlci1yZXBvcnQuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBb0U7QUFDSjtBQVFoRTtJQU1JLGdDQUNZLG9CQUEwQyxFQUMxQyxHQUFxQjtRQURyQix5QkFBb0IsR0FBcEIsb0JBQW9CLENBQXNCO1FBQzFDLFFBQUcsR0FBSCxHQUFHLENBQWtCO1FBUGpDLGFBQVEsR0FBRyxFQUFFLENBQUM7UUFDZCxvQkFBZSxHQUFHLEVBQUUsQ0FBQztRQUNyQixlQUFVLEdBQUUsS0FBSyxDQUFDO1FBRWxCLFlBQU8sR0FBRyxFQUFFLENBQUM7SUFJWCxDQUFDO0lBQ0gseUNBQVEsR0FBUixjQUFtQixDQUFDO0lBQ3BCLHlDQUFRLEdBQVI7UUFBQSxpQkFjQztRQWJHLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUNyQyxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxjQUFJO1lBQzVFLEtBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1lBQ3ZCLElBQUcsS0FBSSxDQUFDLFVBQVUsRUFBQztnQkFDZixLQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzthQUMxQjtpQkFBTTtnQkFDSCxLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQzthQUMzQjtRQUNMLENBQUMsRUFDRCxhQUFHO1lBQ0MsS0FBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7WUFDeEIsS0FBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUNyQyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7O2dCQWxCaUMsNEVBQW9CO2dCQUNyQyw4REFBZ0I7O0lBUnhCLHNCQUFzQjtRQU5sQywrREFBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLG1CQUFtQjtZQUM3QixvRUFBOEM7O1NBR2pELENBQUM7eUNBUW9DLDRFQUFvQjtZQUNyQyw4REFBZ0I7T0FSeEIsc0JBQXNCLENBMEJsQztJQUFELDZCQUFDO0NBQUE7QUExQmtDIiwiZmlsZSI6ImJ1bmRsZS5lMDBlZjQ4NmI5MjZjMGZjOGYyZC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIFZpZXdDb250YWluZXJSZWYgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBXZWF0aGVyUmVwb3J0U2VydmljZSB9IGZyb20gXCIuL3dlYXRoZXItcmVwb3J0LnNlcnZpY2VcIjtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgc2VsZWN0b3I6ICducy13ZWF0aGVyLXJlcG9ydCcsXHJcbiAgICB0ZW1wbGF0ZVVybDogJy4vd2VhdGhlci1yZXBvcnQuY29tcG9uZW50Lmh0bWwnLFxyXG4gICAgc3R5bGVVcmxzOiBbJy4vd2VhdGhlci1yZXBvcnQuY29tcG9uZW50LmNzcyddLFxyXG4gICAgbW9kdWxlSWQ6IG1vZHVsZS5pZFxyXG59KVxyXG5leHBvcnQgY2xhc3MgV2VhdGhlclJlcG9ydENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBjaXR5TmFtZSA9ICcnO1xyXG4gICAgY3VycmVudENpdHlOYW1lID0gJyc7XHJcbiAgICBncmlkc3RhdHVzPSBmYWxzZTtcclxuICAgIGNpdHlSZXBvcnQ6IGFueTtcclxuICAgIGVyckluZm8gPSAnJztcclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHByaXZhdGUgd2VhdGhlclJlcG9ydFNlcnZpY2U6IFdlYXRoZXJSZXBvcnRTZXJ2aWNlLFxyXG4gICAgICAgIHByaXZhdGUgdmNyOiBWaWV3Q29udGFpbmVyUmVmXHJcbiAgICApe31cclxuICAgIG5nT25Jbml0KCk6IHZvaWQgeyB9XHJcbiAgICBvbkNoYW5nZSgpIHtcclxuICAgICAgICB0aGlzLmN1cnJlbnRDaXR5TmFtZSA9IHRoaXMuY2l0eU5hbWU7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMud2VhdGhlclJlcG9ydFNlcnZpY2Uuc2VhcmNoQ2l0eSh0aGlzLmN1cnJlbnRDaXR5TmFtZSkuc3Vic2NyaWJlKGRhdGEgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmNpdHlSZXBvcnQgPSBkYXRhO1xyXG4gICAgICAgICAgICBpZih0aGlzLmNpdHlSZXBvcnQpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ncmlkc3RhdHVzID0gdHJ1ZTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuZ3JpZHN0YXR1cyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlcnIgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRzdGF0dXMgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5lcnJJbmZvID0gZXJyLmVycm9yLm1lc3NhZ2U7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9